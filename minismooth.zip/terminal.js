(function() {
  const style = document.createElement('style');
  style.textContent = `
    #terminal {
      display: none;
      position: fixed;
      inset: 0;
      background: #000;
      color: #fff;
      font-family: monospace;
      padding: 10px;
      z-index: 9999;
      overflow-y: auto;
    }
    #terminal-output {
      white-space: pre-wrap;
    }
    #terminal-input-line {
      display: flex;
      align-items: center;
    }
    #terminal-prompt {
      margin-right: 5px;
      color: #0f0;
    }
    #terminal-input {
      flex-grow: 1;
      border: none;
      outline: none;
      background: transparent;
      color: #fff;
      font-family: monospace;
    }
    #nano-editor {
      position: fixed;
      top: 10%;
      left: 10%;
      width: 80%;
      height: 70%;
      background: #111;
      color: #fff;
      font-family: monospace;
      display: none;
      z-index: 10000;
      padding: 10px;
      box-sizing: border-box;
    }
    #nano-editor textarea {
      width: 100%;
      height: 80%;
      background: #000;
      color: #0f0;
      font-family: monospace;
      border: none;
      resize: none;
    }
  `;
  document.head.appendChild(style);

  const termHTML = document.createElement('div');
  termHTML.innerHTML = `
    <div id="terminal">
      <div id="terminal-output"></div>
      <div id="terminal-input-line">
        <span id="terminal-prompt">smooth$</span>
        <input id="terminal-input" type="text" autofocus />
      </div>
    </div>
    <div id="nano-editor">
      <div>Editing <span id="nano-filename"></span> — <button onclick="saveNano()">Save</button> <button onclick="closeNano()">Close</button></div>
      <textarea id="nano-textarea"></textarea>
    </div>
  `;
  document.body.appendChild(termHTML);

  const terminal = document.getElementById('terminal');
  const termInput = document.getElementById('terminal-input');
  const termOutput = document.getElementById('terminal-output');
  const termPrompt = document.getElementById('terminal-prompt');
  const nanoEditor = document.getElementById('nano-editor');
  const nanoTextarea = document.getElementById('nano-textarea');
  const nanoFilename = document.getElementById('nano-filename');

  let fileSystem = JSON.parse(localStorage.getItem('minios_fs') || '{}');
  if (!fileSystem.root) fileSystem = { root: {} };
  let currentDir = fileSystem.root;
  let currentPath = ['root'];

  function updatePrompt() {
    const path = currentPath.slice(1).join("/") || "";
    termPrompt.textContent = `smooth${path ? "/" + path : ""}$`;
  }

  function saveFileSystem() {
    localStorage.setItem('minios_fs', JSON.stringify(fileSystem));
  }

  function resolvePath(pathArray) {
    return pathArray.reduce((dir, part) => dir?.[part], fileSystem);
  }

  function print(msg) {
    termOutput.innerHTML += msg + '\n';
    terminal.scrollTop = terminal.scrollHeight;
  }

  function listCurrentDir() {
    return Object.keys(currentDir).join("  ");
  }

  function runCommand(cmd) {
    const args = cmd.trim().split(/\s+/);
    const main = args[0];

    switch (main) {
      case "ls":
        print(listCurrentDir() || "(empty)");
        break;

      case "cd":
        if (!args[1]) {
          // cd with no argument goes home
          currentPath = ['root'];
          currentDir = fileSystem.root;
          updatePrompt();
          break;
        }
        if (args[1] === "..") {
          if (currentPath.length > 1) {
            currentPath.pop();
            currentDir = resolvePath(currentPath);
            updatePrompt();
          }
        } else if (currentDir[args[1]] && typeof currentDir[args[1]] === "object") {
          currentPath.push(args[1]);
          currentDir = currentDir[args[1]];
          updatePrompt();
        } else {
          print("No such directory.");
        }
        break;

      case "mkdir":
        if (!args[1]) return print("Usage: mkdir <name>");
        if (currentDir[args[1]]) return print("Directory already exists.");
        currentDir[args[1]] = {};
        saveFileSystem();
        print("Directory created.");
        break;

      case "new":
        if (!args[1]) return print("Usage: new <filename>");
        if (currentDir[args[1]]) return print("File already exists.");
        currentDir[args[1]] = "";
        saveFileSystem();
        print("File created.");
        break;

      case "nano":
        if (!args[1]) return print("Usage: nano <filename>");
        nanoFilename.textContent = args[1];
        nanoTextarea.value = currentDir[args[1]] || "";
        nanoEditor.style.display = "block";
        break;

      case "rm":
        if (!args[1]) return print("Usage: rm <filename|folder>");
        if (currentDir[args[1]]) {
          delete currentDir[args[1]];
          saveFileSystem();
          print("Deleted.");
        } else {
          print("Not found.");
        }
        break;

      case "cat":
        if (!args[1]) return print("Usage: cat <filename>");
        const content = currentDir[args[1]];
        if (typeof content === "string") {
          print(content);
        } else {
          print("Not a file.");
        }
        break;

      case "run":
        if (!args[1]) return print("Usage: run <filename>");
        if (typeof currentDir[args[1]] !== "string") return print("File not found or not a text file.");
        try {
          new Function(currentDir[args[1]])();
          print("Executed.");
        } catch (e) {
          print("Error: " + e.message);
        }
        break;

      case "webget":
        if (!args[1]) return print("Usage: webget <url> [filename]");
        const url = args[1];
        let filename = args[2];
        if (!filename) {
          try {
            const urlParts = new URL(url).pathname.split('/');
            filename = urlParts[urlParts.length - 1] || 'download.txt';
          } catch {
            return print("Invalid URL.");
          }
        }
        fetch(url).then(r => {
          if (!r.ok) throw new Error(`HTTP ${r.status}`);
          return r.text();
        }).then(data => {
          currentDir[filename] = data;
          saveFileSystem();
          print(`Downloaded ${filename}`);
        }).catch(e => print("Failed: " + e.message));
        break;

      case "clear":
        termOutput.innerHTML = "";
        break;

      case "welcome":
        print("Welcome to the MiniOS terminal\nMiniSmooth Mod\nUser: smooth");
        break;

      case "help":
        print(`Available commands:
  ls                 – list files and folders
  cd <dir>           – change directory (cd alone goes home)
  mkdir <name>       – create new directory
  new <file>         – create new empty file
  nano <file>        – edit file with nano editor
  cat <file>         – show contents of a file
  run <file>         – run JS in file
  rm <file|folder>   – remove file or folder
  webget <url> [file]– download and save file
  clear              – clear the terminal screen
  welcome            – show welcome message
  help               – show this help menu`);
        break;

      default:
        print(`Unknown command: ${main}`);
    }
  }

  window.saveNano = function () {
    const filename = nanoFilename.textContent;
    currentDir[filename] = nanoTextarea.value;
    saveFileSystem();
    closeNano();
    print(`Saved ${filename}`);
  };

  window.closeNano = function () {
    nanoEditor.style.display = "none";
  };

  termInput.addEventListener("keydown", e => {
    if (e.key === "Enter") {
      const input = termInput.value;
      print(`${termPrompt.textContent} ${input}`);
      runCommand(input);
      termInput.value = "";
    }
  });

  document.addEventListener("keydown", e => {
    if (e.shiftKey && e.altKey && e.key.toLowerCase() === "t") {
      terminal.style.display = terminal.style.display === "block" ? "none" : "block";
      termInput.focus();
      updatePrompt();
      if (terminal.style.display === "block") {
        print("Welcome to the MiniOS terminal\nMiniSmooth Mod\nUser: smooth");
      }
    }
  });

  // Init prompt
  updatePrompt();
})();
